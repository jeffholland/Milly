var searchData=
[
  ['saveprompt_0',['SavePrompt',['../classsave__prompt_1_1_save_prompt.html',1,'save_prompt']]],
  ['settings_1',['Settings',['../classsettings_1_1_settings.html',1,'settings']]],
  ['showcolorschemes_2',['ShowColorSchemes',['../classshow__schemes_1_1_show_color_schemes.html',1,'show_schemes']]],
  ['stats_3',['Stats',['../classstats_1_1_stats.html',1,'stats']]]
];
