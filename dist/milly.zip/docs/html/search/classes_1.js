var searchData=
[
  ['colors_0',['Colors',['../classcolors_1_1_colors.html',1,'colors']]],
  ['colorschemesettings_1',['ColorSchemeSettings',['../classsettings__colorscheme_1_1_color_scheme_settings.html',1,'settings_colorscheme']]]
];
