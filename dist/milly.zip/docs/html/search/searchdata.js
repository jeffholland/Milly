var indexSectionsWithContent =
{
  0: "acefikms",
  1: "acefiks",
  2: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces"
};

