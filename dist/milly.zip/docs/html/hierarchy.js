var hierarchy =
[
    [ "colors.Colors", "classcolors_1_1_colors.html", null ],
    [ "tk.Frame", null, [
      [ "entries.Entries", "classentries_1_1_entries.html", null ],
      [ "entry.Entry", "classentry_1_1_entry.html", null ],
      [ "entry_group.EntryGroup", "classentry__group_1_1_entry_group.html", null ],
      [ "entry_menu.EntryMenu", "classentry__menu_1_1_entry_menu.html", null ],
      [ "export.ExportWindow", "classexport_1_1_export_window.html", null ],
      [ "find.FindWindow", "classfind_1_1_find_window.html", null ],
      [ "input.Input", "classinput_1_1_input.html", null ],
      [ "input_buttons.InputButtons", "classinput__buttons_1_1_input_buttons.html", null ],
      [ "input_path.InputPath", "classinput__path_1_1_input_path.html", null ],
      [ "input_path_browser.InputPathBrowser", "classinput__path__browser_1_1_input_path_browser.html", null ],
      [ "insert_prompt.InsertPrompt", "classinsert__prompt_1_1_insert_prompt.html", null ],
      [ "milly.Application", "classmilly_1_1_application.html", null ],
      [ "save_prompt.SavePrompt", "classsave__prompt_1_1_save_prompt.html", null ],
      [ "settings.Settings", "classsettings_1_1_settings.html", null ],
      [ "settings_colorscheme.ColorSchemeSettings", "classsettings__colorscheme_1_1_color_scheme_settings.html", null ],
      [ "settings_entry.EntrySettings", "classsettings__entry_1_1_entry_settings.html", null ],
      [ "settings_font.FontSettings", "classsettings__font_1_1_font_settings.html", null ],
      [ "show_schemes.ShowColorSchemes", "classshow__schemes_1_1_show_color_schemes.html", null ],
      [ "stats.Stats", "classstats_1_1_stats.html", null ]
    ] ],
    [ "key.Key", "classkey_1_1_key.html", null ]
];